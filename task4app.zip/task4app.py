from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

notes = []

@app.route('/')
def index():
    return render_template("home.html", notes=notes)

@app.route('/add_note', methods=["POST"])
def add_note():
    note = request.form.get("note")
    if note.strip():
        notes.append(note)
        return jsonify({"success": True, "note": note})
    else:
        return jsonify({"success": False, "error": "Note cannot be empty"})

if __name__ == '__main__':
    app.run(debug=True)